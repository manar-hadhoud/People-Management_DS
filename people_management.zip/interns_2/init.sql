CREATE TYPE employee_gender AS ENUM ('M', 'F');

CREATE TABLE IF NOT EXISTS department (
    id character(4) NOT NULL,
    dept_name character varying(40) NOT NULL
);

CREATE TABLE IF NOT EXISTS department_employee (
    employee_id bigint NOT NULL,
    department_id character(4) NOT NULL,
    from_date date NOT NULL,
    to_date date NOT NULL
);

CREATE TABLE IF NOT EXISTS department_manager (
    employee_id bigint NOT NULL,
    department_id character(4) NOT NULL,
    from_date date NOT NULL,
    to_date date NOT NULL
);


CREATE TABLE IF NOT EXISTS employee (
    id bigint NOT NULL,
    birth_date date NOT NULL,
    first_name character varying(14) NOT NULL,
    last_name character varying(16) NOT NULL,
    gender employee_gender NOT NULL,
    hire_date date NOT NULL
);


CREATE TABLE IF NOT EXISTS salary (
    employee_id bigint NOT NULL,
    amount bigint NOT NULL,
    from_date date NOT NULL,
    to_date date NOT NULL
);

CREATE TABLE IF NOT EXISTS title (
    employee_id bigint NOT NULL,
    title character varying(50) NOT NULL,
    from_date date NOT NULL,
    to_date date
);


-- Create table IF NOT EXISTSs
CREATE TABLE IF NOT EXISTS department (
    id character(4) NOT NULL,
    dept_name character varying(40) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS department_employee (
    employee_id bigint NOT NULL,
    department_id character(4) NOT NULL,
    from_date date NOT NULL,
    to_date date NOT NULL,
    PRIMARY KEY (employee_id, department_id),
    FOREIGN KEY (employee_id) REFERENCES employee(id) ON DELETE CASCADE,
    FOREIGN KEY (department_id) REFERENCES department(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS department_manager (
    employee_id bigint NOT NULL,
    department_id character(4) NOT NULL,
    from_date date NOT NULL,
    to_date date NOT NULL,
    PRIMARY KEY (employee_id, department_id),
    FOREIGN KEY (employee_id) REFERENCES employee(id) ON DELETE CASCADE,
    FOREIGN KEY (department_id) REFERENCES department(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS employee (
    id bigint NOT NULL,
    birth_date date NOT NULL,
    first_name character varying(14) NOT NULL,
    last_name character varying(16) NOT NULL,
    gender character(1) NOT NULL,
    hire_date date NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS salary (
    employee_id bigint NOT NULL,
    amount bigint NOT NULL,
    from_date date NOT NULL,
    to_date date NOT NULL,
    PRIMARY KEY (employee_id, from_date),
    FOREIGN KEY (employee_id) REFERENCES employee(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS title (
    employee_id bigint NOT NULL,
    title character varying(50) NOT NULL,
    from_date date NOT NULL,
    to_date date,
    PRIMARY KEY (employee_id, title, from_date),
    FOREIGN KEY (employee_id) REFERENCES employee(id) ON DELETE CASCADE
);

-- Load data from CSV files




ALTER TABLE ONLY department
    ADD CONSTRAINT idx_16979_primary PRIMARY KEY (id);


ALTER TABLE ONLY department_employee
    ADD CONSTRAINT idx_16982_primary PRIMARY KEY (employee_id, department_id);


ALTER TABLE ONLY department_manager
    ADD CONSTRAINT idx_16985_primary PRIMARY KEY (employee_id, department_id);


ALTER TABLE ONLY employee
    ADD CONSTRAINT idx_16988_primary PRIMARY KEY (id);


ALTER TABLE ONLY salary
    ADD CONSTRAINT idx_16991_primary PRIMARY KEY (employee_id, from_date);



ALTER TABLE ONLY title
    ADD CONSTRAINT idx_16994_primary PRIMARY KEY (employee_id, title, from_date);


CREATE UNIQUE INDEX idx_16979_dept_name ON department USING btree (dept_name);
CREATE INDEX idx_16982_dept_no ON department_employee USING btree (department_id);
CREATE INDEX idx_16985_dept_no ON department_manager USING btree (department_id);

ALTER TABLE ONLY department_employee
    ADD CONSTRAINT dept_emp_ibfk_1 FOREIGN KEY (employee_id) REFERENCES employee(id) ON UPDATE RESTRICT ON DELETE CASCADE;

ALTER TABLE ONLY department_employee
    ADD CONSTRAINT dept_emp_ibfk_2 FOREIGN KEY (department_id) REFERENCES department(id) ON UPDATE RESTRICT ON DELETE CASCADE;

ALTER TABLE ONLY department_manager
    ADD CONSTRAINT dept_manager_ibfk_1 FOREIGN KEY (employee_id) REFERENCES employee(id) ON UPDATE RESTRICT ON DELETE CASCADE;

ALTER TABLE ONLY department_manager
    ADD CONSTRAINT dept_manager_ibfk_2 FOREIGN KEY (department_id) REFERENCES department(id) ON UPDATE RESTRICT ON DELETE CASCADE;

ALTER TABLE ONLY salary
    ADD CONSTRAINT salaries_ibfk_1 FOREIGN KEY (employee_id) REFERENCES employee(id) ON UPDATE RESTRICT ON DELETE CASCADE;

ALTER TABLE ONLY title
    ADD CONSTRAINT titles_ibfk_1 FOREIGN KEY (employee_id) REFERENCES employee(id) ON UPDATE RESTRICT ON DELETE CASCADE;



COPY department(id, dept_name) FROM '/docker-entrypoint-initdb.d/department.csv' DELIMITER ',' CSV HEADER;
COPY employee(id, birth_date, first_name, last_name, gender, hire_date) FROM '/docker-entrypoint-initdb.d/employee.csv' DELIMITER ',' CSV HEADER;

COPY department_employee(employee_id, department_id, from_date, to_date) FROM '/docker-entrypoint-initdb.d/department_employee.csv' DELIMITER ',' CSV HEADER;
COPY department_manager(employee_id, department_id, from_date, to_date) FROM '/docker-entrypoint-initdb.d/department_manager.csv' DELIMITER ',' CSV HEADER;
COPY salary(employee_id, amount, from_date, to_date) FROM '/docker-entrypoint-initdb.d/salary.csv' DELIMITER ',' CSV HEADER;
COPY title(employee_id, title, from_date, to_date) FROM '/docker-entrypoint-initdb.d/title.csv' DELIMITER ',' CSV HEADER;


